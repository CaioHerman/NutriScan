import { GoogleGenAI, Type } from "@google/genai";
import { NutritionData, Language } from "../types";

const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

/**
 * Analisa uma imagem de refeição usando o modelo Gemini 3 Pro.
 * Inclui lógica de sanitização de resposta e retentativas automáticas.
 */
export const analyzeMeal = async (
  base64Image: string, 
  mimeType: string, 
  language: Language,
  retries = 2
): Promise<NutritionData> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const langMap = {
    pt: "Português (Brasil)",
    en: "English (US)",
    es: "Español (Latinoamérica)"
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        {
          parts: [
            {
              inlineData: {
                data: base64Image,
                mimeType: mimeType,
              },
            },
            {
              text: `Você é um nutricionista clínico de elite com especialidade em análise visual de alimentos. 
              Analise esta imagem e forneça um relatório detalhado.
              
              REGRAS CRÍTICAS:
              1. Idioma: ${langMap[language]}.
              2. Saída: EXCLUSIVAMENTE JSON válido.
              3. Se não houver comida na imagem, retorne um erro amigável no campo 'summary'.
              
              Estrutura esperada:
              - foodName: Nome claro do prato.
              - calories: Valor calórico aproximado (número).
              - protein/carbs/fats/fiber/sugar: Gramas (número).
              - sodium: Miligramas (número).
              - healthScore: Nota de saúde de 1 a 10.
              - satietyLevel: 'Baixo', 'Médio' ou 'Alto'.
              - ingredients: Lista de 4 a 6 componentes visíveis.
              - summary: Uma breve explicação do perfil nutricional.`,
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            foodName: { type: Type.STRING },
            calories: { type: Type.NUMBER },
            protein: { type: Type.NUMBER },
            carbs: { type: Type.NUMBER },
            fats: { type: Type.NUMBER },
            fiber: { type: Type.NUMBER },
            sugar: { type: Type.NUMBER },
            sodium: { type: Type.NUMBER },
            healthScore: { type: Type.NUMBER },
            satietyLevel: { type: Type.STRING },
            ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            summary: { type: Type.STRING },
          },
          required: ["foodName", "calories", "protein", "carbs", "fats", "fiber", "sugar", "sodium", "healthScore", "satietyLevel", "ingredients", "summary"],
        },
      },
    });

    const responseText = response.text;
    if (!responseText) throw new Error("IA retornou resposta vazia");

    // Limpeza de Markdown caso a IA ignore o config de mimeType
    let cleanJson = responseText.trim();
    if (cleanJson.includes('```')) {
      cleanJson = cleanJson.replace(/```json|```/g, '').trim();
    }
    
    // Extração do bloco JSON principal caso haja ruído
    const match = cleanJson.match(/\{[\s\S]*\}/);
    if (match) {
      cleanJson = match[0];
    }
    
    return JSON.parse(cleanJson) as NutritionData;
  } catch (e: any) {
    if (retries > 0) {
      console.warn(`Tentativa falhou. Tentando novamente... (${retries} restantes)`);
      await wait(1000);
      return analyzeMeal(base64Image, mimeType, language, retries - 1);
    }
    console.error("Erro Crítico no GeminiService:", e);
    throw new Error(language === 'pt' ? "Não conseguimos analisar a imagem. Tente novamente com mais luz." : "Analysis failed. Try with better lighting.");
  }
};