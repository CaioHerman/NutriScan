import React, { useRef, useState, useEffect, useCallback } from 'react';
import { X, RefreshCw, Image as ImageIcon, Zap, AlertTriangle, ShieldOff } from 'lucide-react';
import { CameraResult, Language } from '../types';
import { translations } from '../translations';

interface CameraViewProps {
  onCapture: (result: CameraResult) => void;
  onCancel: () => void;
  language: Language;
}

export const CameraView: React.FC<CameraViewProps> = ({ onCapture, onCancel, language }) => {
  const t = translations[language];
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  const [status, setStatus] = useState<'initializing' | 'ready' | 'error' | 'denied'>('initializing');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);

  const stopTracks = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const initCamera = useCallback(async () => {
    setStatus('initializing');
    setErrorMsg(null);
    stopTracks();

    try {
      const constraints: MediaStreamConstraints = {
        video: { 
          facingMode: 'environment', 
          width: { ideal: 1280 }, 
          height: { ideal: 720 } 
        },
        audio: false
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setStatus('ready');
      }
    } catch (err: any) {
      console.error("Camera Init Error:", err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setStatus('denied');
      } else {
        setStatus('error');
        setErrorMsg(err.message);
      }
    }
  }, [stopTracks]);

  useEffect(() => {
    initCamera();
    return () => stopTracks();
  }, [initCamera, stopTracks]);

  const processAndCapture = (source: HTMLVideoElement | HTMLImageElement) => {
    // Efeito visual de Flash
    setIsFlashing(true);
    setTimeout(() => setIsFlashing(false), 150);

    const canvas = document.createElement('canvas');
    const MAX_WIDTH = 1024;
    let width = source instanceof HTMLVideoElement ? source.videoWidth : source.width;
    let height = source instanceof HTMLVideoElement ? source.videoHeight : source.height;

    if (width > MAX_WIDTH) {
      height = Math.round((height * MAX_WIDTH) / width);
      width = MAX_WIDTH;
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Pequeno ajuste de brilho para melhorar a detecção da IA
      ctx.filter = 'contrast(1.1) brightness(1.05)';
      ctx.drawImage(source, 0, 0, width, height);
      const base64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
      onCapture({ base64, mimeType: 'image/jpeg' });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => processAndCapture(img);
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-black relative safe-pt safe-pb overflow-hidden">
      {/* Visual Flash Layer */}
      <div className={`absolute inset-0 bg-white z-[100] transition-opacity duration-150 pointer-events-none ${isFlashing ? 'opacity-80' : 'opacity-0'}`} />

      <div className="absolute top-12 left-6 right-6 z-50 flex justify-between items-center">
        <button onClick={onCancel} className="p-3 bg-black/40 backdrop-blur-xl rounded-full text-white border border-white/10 active:scale-90 transition-transform">
          <X size={24} />
        </button>
        <div className="bg-emerald-500/90 backdrop-blur-md px-4 py-1.5 rounded-full shadow-lg border border-emerald-400/20">
          <span className="text-white text-[10px] font-black tracking-widest uppercase">Scanner Pro v1.1</span>
        </div>
      </div>

      {status === 'initializing' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 z-40">
          <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4" />
          <p className="text-emerald-500 font-bold tracking-widest text-[10px] uppercase">Ajustando Lente...</p>
        </div>
      )}

      {status === 'denied' ? (
        <div className="flex-1 flex flex-col items-center justify-center p-10 text-center text-white bg-slate-900 z-50">
          <ShieldOff size={48} className="text-amber-500 mb-6" />
          <h2 className="text-xl font-bold mb-2">Acesso Negado</h2>
          <p className="text-slate-400 text-sm mb-8">Precisamos da câmera para analisar sua comida. Ative nas configurações do sistema.</p>
          <button onClick={() => window.location.reload()} className="w-full py-4 bg-white text-black rounded-2xl font-bold active:scale-95 transition-transform">Tentar Novamente</button>
        </div>
      ) : status === 'error' ? (
        <div className="flex-1 flex flex-col items-center justify-center p-10 text-center text-white bg-slate-900 z-50">
          <AlertTriangle size={48} className="text-red-500 mb-6" />
          <h2 className="text-xl font-bold mb-4">Falha na Lente</h2>
          <div className="w-full space-y-3">
            <button onClick={initCamera} className="w-full py-4 bg-emerald-500 rounded-2xl font-bold flex items-center justify-center gap-2 active:scale-95">
              <RefreshCw size={20} /> Reiniciar Câmera
            </button>
            <label className="flex items-center justify-center gap-2 w-full py-4 bg-white/10 rounded-2xl font-bold cursor-pointer active:scale-95">
              <ImageIcon size={20} /> Galeria de Fotos
              <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
            </label>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col relative">
          <video ref={videoRef} playsInline muted autoPlay className="flex-1 object-cover" />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <div className="w-72 h-72 border-2 border-emerald-500/30 rounded-[48px] relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-emerald-400/60 animate-scan shadow-[0_0_20px_rgba(52,211,153,0.8)]" />
             </div>
          </div>
          <div className="absolute bottom-12 left-0 w-full flex items-center justify-evenly px-8">
            <label className="p-4 bg-black/40 backdrop-blur-xl rounded-full text-white border border-white/20 cursor-pointer active:scale-90 transition-transform">
              <ImageIcon size={24} />
              <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
            </label>
            <button 
              onClick={() => videoRef.current && processAndCapture(videoRef.current)}
              className="w-20 h-20 bg-white rounded-full p-1.5 shadow-[0_0_40px_rgba(52,211,153,0.3)] active:scale-90 transition-transform"
            >
              <div className="w-full h-full rounded-full border-4 border-slate-100 flex items-center justify-center bg-white">
                 <Zap size={32} className="text-emerald-500 fill-emerald-500" />
              </div>
            </button>
            <button onClick={onCancel} className="p-4 bg-black/40 backdrop-blur-xl rounded-full text-white border border-white/20 active:scale-90 transition-transform">
              <X size={24} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};