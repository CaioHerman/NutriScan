
import React from 'react';
import { ArrowLeft, Shield, FileText, HelpCircle, Star, Trash2, Globe, Mail } from 'lucide-react';
import { AppState, Language } from '../types';
import { translations } from '../translations';

interface SettingsViewProps {
  onBack: () => void;
  language: Language;
  onNavigate: (s: AppState) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onBack, language, onNavigate }) => {
  const t = translations[language];

  const handleReset = () => {
    if (confirm("Deseja realmente apagar todo o histórico e resetar o app?")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const handleRate = () => {
    window.open("https://ai.google.dev", "_blank");
  };

  const handleSupport = () => {
    window.location.href = "mailto:suporte@nutriscan.app?subject=Suporte NutriScan";
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50">
      <div className="p-8 pt-16 bg-white border-b border-slate-100 flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors active:scale-90">
          <ArrowLeft size={24} className="text-slate-600" />
        </button>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">{t.settings}</h2>
      </div>

      <div className="p-6 space-y-4">
        <button 
          onClick={() => onNavigate('PRIVACY')}
          className="w-full p-6 bg-white rounded-[32px] shadow-sm border border-slate-100 flex items-center gap-4 font-bold text-slate-700 active:bg-slate-50 active:scale-[0.98] transition-all"
        >
          <div className="bg-emerald-100 p-2.5 rounded-xl">
            <Shield size={20} className="text-emerald-600" />
          </div>
          <span>{t.privacy}</span>
        </button>

        <button 
          onClick={() => onNavigate('TERMS')}
          className="w-full p-6 bg-white rounded-[32px] shadow-sm border border-slate-100 flex items-center gap-4 font-bold text-slate-700 active:bg-slate-50 active:scale-[0.98] transition-all"
        >
          <div className="bg-blue-100 p-2.5 rounded-xl">
            <FileText size={20} className="text-blue-600" />
          </div>
          <span>{t.terms}</span>
        </button>

        <button 
          onClick={handleSupport}
          className="w-full p-6 bg-white rounded-[32px] shadow-sm border border-slate-100 flex items-center gap-4 font-bold text-slate-700 active:bg-slate-50 active:scale-[0.98] transition-all"
        >
          <div className="bg-purple-100 p-2.5 rounded-xl">
            <HelpCircle size={20} className="text-purple-600" />
          </div>
          <div className="flex-1 text-left">
            <span>Ajuda & Suporte</span>
            <p className="text-[10px] text-slate-400 font-medium">Falar com a equipe</p>
          </div>
          <Mail size={18} className="text-slate-300" />
        </button>

        <button 
          onClick={handleRate}
          className="w-full p-6 bg-gradient-to-br from-amber-400 to-orange-500 rounded-[32px] shadow-xl shadow-amber-100 text-white flex items-center justify-between font-black active:scale-95 transition-all"
        >
          Avaliar NutriScan <Star size={24} className="fill-white" />
        </button>
        
        <div className="pt-12 flex flex-col items-center">
          <button onClick={handleReset} className="text-red-400 font-bold flex items-center gap-2 text-sm p-4 active:bg-red-50 rounded-2xl transition-all">
            <Trash2 size={18} /> Resetar Dados do App
          </button>
          <div className="mt-4 flex items-center gap-2 text-slate-300 text-[10px] font-bold uppercase tracking-widest">
            <Globe size={12} /> v1.0.0 NutriScan Native
          </div>
        </div>
      </div>
    </div>
  );
};
