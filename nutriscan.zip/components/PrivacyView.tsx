
import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { ArrowLeft, ShieldCheck, Mail } from 'lucide-react';

interface PrivacyViewProps {
  language: Language;
  onBack: () => void;
}

export const PrivacyView: React.FC<PrivacyViewProps> = ({ language, onBack }) => {
  const t = translations[language];

  return (
    <div className="flex-1 flex flex-col bg-white">
      <div className="p-6 border-b border-slate-100 flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
          <ArrowLeft size={20} className="text-slate-600" />
        </button>
        <h2 className="text-xl font-bold text-slate-800">{t.privacy}</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-6 text-slate-600 text-sm leading-relaxed">
        <div className="flex justify-center py-4 text-emerald-500">
          <ShieldCheck size={48} />
        </div>
        
        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">1. Coleta de Dados</h3>
          <p>O <strong>NutriScan</strong> solicita acesso à sua câmera para capturar fotos de refeições. Essas imagens são processadas momentaneamente para extrair informações nutricionais.</p>
        </section>

        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">2. Uso de Inteligência Artificial</h3>
          <p>Utilizamos a tecnologia Google Gemini para analisar as fotos. As imagens são enviadas de forma segura para os servidores da Google para processamento e não são armazenadas permanentemente por nós fora do seu histórico local.</p>
        </section>

        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">3. Armazenamento Local</h3>
          <p>Seu histórico de refeições e fotos é armazenado localmente no seu dispositivo para sua conveniência. Se você limpar os dados do app ou desinstalá-lo, essas informações serão removidas.</p>
        </section>

        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">4. Contato</h3>
          <p>Para dúvidas, suporte ou solicitações de dados, entre em contato conosco:</p>
          <div className="flex items-center gap-2 text-emerald-600 font-bold mt-2 bg-emerald-50 p-3 rounded-xl">
            <Mail size={16} />
            suporte@nutriscan.app
          </div>
        </section>

        <div className="pt-8 text-center text-slate-400 text-xs">
          Última atualização: Março de 2025
        </div>
      </div>
    </div>
  );
};
