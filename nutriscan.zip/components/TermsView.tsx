
import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { ArrowLeft, FileText } from 'lucide-react';

interface TermsViewProps {
  language: Language;
  onBack: () => void;
}

export const TermsView: React.FC<TermsViewProps> = ({ language, onBack }) => {
  const t = translations[language];

  return (
    <div className="flex-1 flex flex-col bg-white">
      <div className="p-6 border-b border-slate-100 flex items-center gap-4">
        <button onClick={onBack} aria-label="Voltar" className="p-2 hover:bg-slate-100 rounded-full transition-colors">
          <ArrowLeft size={20} className="text-slate-600" />
        </button>
        <h2 className="text-xl font-bold text-slate-800">{t.terms}</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-6 text-slate-600 text-sm leading-relaxed">
        <div className="flex justify-center py-4 text-emerald-500">
          <FileText size={48} />
        </div>
        
        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">1. Aceitação dos Termos</h3>
          <p>Ao utilizar o NutriScan, você concorda em cumprir estes termos. O app fornece estimativas nutricionais baseadas em IA e não substitui o conselho de um nutricionista ou médico.</p>
        </section>

        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">2. Assinaturas e Pagamentos</h3>
          <p>As assinaturas Premium são processadas pela Google Play Store. O cancelamento pode ser feito a qualquer momento nas configurações da sua conta Google.</p>
        </section>

        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">3. Responsabilidade Nutricional</h3>
          <p>As informações fornecidas são estimativas. O NutriScan não se responsabiliza por decisões dietéticas tomadas exclusivamente com base nos dados do app. Verifique sempre os rótulos físicos dos alimentos.</p>
        </section>

        <section className="space-y-2">
          <h3 className="font-bold text-slate-800 text-base">4. Uso de IA</h3>
          <p>A precisão da análise depende da qualidade da foto e da complexidade da refeição. Alimentos ocultos ou misturados podem não ser detectados corretamente.</p>
        </section>

        <div className="pt-8 text-center text-slate-400 text-xs italic">
          NutriScan - Seu guia nutricional por imagem.
        </div>
      </div>
    </div>
  );
};
