
import React from 'react';
import { translations } from '../translations';
import { Language } from '../types';
import { CheckCircle2, Star, ShieldCheck, Zap, ArrowLeft } from 'lucide-react';

interface PaywallProps {
  language: Language;
  onSubscribe: () => void;
}

export const Paywall: React.FC<PaywallProps> = ({ language, onSubscribe }) => {
  const t = translations[language];

  const handleRestore = () => {
    alert(language === 'pt' ? "Nenhuma assinatura anterior encontrada para esta conta." : "No previous subscription found for this account.");
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-white p-8 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute -top-20 -left-20 w-64 h-64 bg-emerald-500/20 rounded-full blur-[80px]" />
      <div className="absolute top-1/2 -right-20 w-64 h-64 bg-blue-500/10 rounded-full blur-[80px]" />

      <div className="pt-12 text-center space-y-4 mb-8 relative z-10">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-[40px] shadow-2xl shadow-emerald-500/40 mb-6 animate-pulse">
          <Star className="text-white w-12 h-12 fill-white" />
        </div>
        <h1 className="text-4xl font-black tracking-tighter leading-none">
          {t.paywallTitle}
        </h1>
        <p className="text-slate-400 text-lg font-medium px-4">
          {t.paywallDesc}
        </p>
      </div>

      <div className="bg-white/5 backdrop-blur-xl rounded-[40px] p-8 border border-white/10 space-y-6 mb-8 relative z-10 shadow-2xl">
        <div className="space-y-4">
          {[
            { icon: CheckCircle2, text: t.unlimitedPhotos },
            { icon: Zap, text: t.iaTech },
            { icon: ShieldCheck, text: t.cancelAnytime }
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4">
              <div className="bg-emerald-500 p-1.5 rounded-lg">
                <item.icon className="text-white w-4 h-4" />
              </div>
              <span className="font-bold text-slate-200">{item.text}</span>
            </div>
          ))}
        </div>

        <div className="pt-6 border-t border-white/10 text-center">
          <div className="inline-block px-3 py-1 bg-amber-400 text-slate-900 text-[10px] font-black rounded-full mb-2 uppercase tracking-widest">
            {language === 'pt' ? 'Oferta Limitada' : 'Limited Offer'}
          </div>
          <p className="text-5xl font-black text-white tracking-tighter">{t.price}</p>
          <p className="text-slate-500 text-[10px] font-bold mt-1 uppercase tracking-widest">
            {language === 'pt' ? 'Renovação Mensal Automática' : 'Automatic Monthly Renewal'}
          </p>
        </div>
      </div>

      <div className="mt-auto space-y-6 relative z-10">
        <button
          onClick={onSubscribe}
          className="w-full py-6 bg-emerald-500 text-white rounded-[32px] font-black text-xl shadow-2xl shadow-emerald-500/40 active:scale-[0.98] transition-all"
        >
          {t.subscribe}
        </button>
        
        <div className="flex flex-col items-center gap-4">
          <button 
            onClick={handleRestore}
            className="text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-white transition-colors"
          >
            {language === 'pt' ? 'Restaurar Compras' : 'Restore Purchases'}
          </button>
          
          <p className="text-[9px] text-slate-600 text-center leading-relaxed px-4">
            {language === 'pt' 
              ? "Ao assinar, você concorda com nossos Termos de Uso e Política de Privacidade. A assinatura será cobrada em sua conta da loja e renovada automaticamente."
              : "By subscribing, you agree to our Terms of Use and Privacy Policy. The subscription will be charged to your store account and will renew automatically."}
          </p>
        </div>
      </div>
    </div>
  );
};
