import React from 'react';
import { NutritionData, Language } from '../types';
import { translations } from '../translations';
import { 
  ArrowLeft, 
  Flame, 
  Share2, 
  Zap, 
  Activity, 
  Droplets, 
  Wind, 
  Scale, 
  AlertCircle,
  CheckCircle2,
  Info
} from 'lucide-react';

interface ResultViewProps {
  data: NutritionData;
  image: string;
  onBack: () => void;
  language: Language;
}

export const ResultView: React.FC<ResultViewProps> = ({ data, image, onBack, language }) => {
  const t = translations[language];

  const totalMacros = data.protein + data.carbs + data.fats || 1;
  const pPct = Math.round((data.protein / totalMacros) * 100);
  const cPct = Math.round((data.carbs / totalMacros) * 100);
  const fPct = Math.round((data.fats / totalMacros) * 100);

  const handleShare = async () => {
    const shareText = `NutriScan: Analisei meu prato "${data.foodName}" - Nota ${data.healthScore}/10! 🥗✨`;
    if (navigator.share) {
      try { await navigator.share({ title: 'NutriScan', text: shareText, url: window.location.href }); } catch (err) {}
    } else {
      navigator.clipboard.writeText(shareText);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-emerald-500';
    if (score >= 6) return 'text-amber-500';
    return 'text-red-500';
  };

  const getScoreBg = (score: number) => {
    if (score >= 8) return 'bg-emerald-500/10 border-emerald-500/20';
    if (score >= 6) return 'bg-amber-500/10 border-amber-500/20';
    return 'bg-red-500/10 border-red-500/20';
  };

  const getSatietyColor = (level: string) => {
    if (level === 'Alto') return 'text-emerald-500';
    if (level === 'Médio') return 'text-blue-500';
    return 'text-slate-400';
  };

  return (
    <div className="flex-1 flex flex-col bg-white page-fade-in overflow-hidden h-full">
      <div className="relative h-64 shrink-0">
        <img src={`data:image/jpeg;base64,${image}`} className="w-full h-full object-cover" alt="Meal" />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-black/30" />
        
        <div className="absolute top-12 left-6 right-6 flex justify-between items-center">
          <button 
            onClick={onBack} 
            className="p-3 bg-white/20 backdrop-blur-xl rounded-2xl text-white border border-white/20 active:scale-90 transition-all shadow-lg"
          >
            <ArrowLeft size={24} />
          </button>
          <button 
            onClick={handleShare}
            className="p-3 bg-white/20 backdrop-blur-xl rounded-2xl text-white border border-white/20 active:scale-90 transition-all shadow-lg"
          >
            <Share2 size={24} />
          </button>
        </div>
      </div>

      <div className="flex-1 -mt-12 bg-white rounded-t-[48px] p-6 space-y-6 overflow-y-auto pb-32 relative z-10 shadow-[0_-20px_50px_rgba(0,0,0,0.1)]">
        
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-widest rounded-md">
                Scanner Pro
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                <Activity size={10} /> Verificado por IA
              </span>
            </div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tighter leading-tight break-words">{data.foodName}</h2>
          </div>
          
          <div className={`p-3 rounded-3xl border text-center min-w-[80px] ${getScoreBg(data.healthScore)}`}>
            <p className={`text-3xl font-black ${getScoreColor(data.healthScore)}`}>{data.healthScore}</p>
            <p className="text-[8px] font-black uppercase tracking-widest text-slate-400">{t.score}</p>
          </div>
        </div>

        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex gap-3 items-start">
          <div className="bg-white p-2 rounded-xl shadow-sm">
            <Info size={18} className="text-emerald-500" />
          </div>
          <p className="text-sm font-medium text-slate-600 leading-snug">
            {data.summary}
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-black text-slate-900 text-xs uppercase tracking-[0.15em]">{t.resultTitle}</h3>
            <div className="flex items-center gap-1 text-orange-500 bg-orange-50 px-3 py-1 rounded-full border border-orange-100">
              <Flame size={14} className="fill-orange-500" />
              <span className="text-sm font-black tracking-tight">{data.calories} kcal</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
            <div className="relative h-4 w-full bg-slate-100 rounded-full overflow-hidden flex">
              <div 
                className="h-full bg-emerald-500 transition-all duration-1000 ease-out" 
                style={{ width: `${pPct}%` }} 
              />
              <div 
                className="h-full bg-amber-400 transition-all duration-1000 ease-out" 
                style={{ width: `${cPct}%` }} 
              />
              <div 
                className="h-full bg-red-400 transition-all duration-1000 ease-out" 
                style={{ width: `${fPct}%` }} 
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{t.protein}</p>
                </div>
                <p className="text-xl font-black text-slate-900 tracking-tight">{data.protein}g</p>
                <div className="h-1 w-8 bg-emerald-100 rounded-full">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${pPct}%` }} />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{t.carbs}</p>
                </div>
                <p className="text-xl font-black text-slate-900 tracking-tight">{data.carbs}g</p>
                <div className="h-1 w-8 bg-amber-100 rounded-full">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${cPct}%` }} />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-red-400" />
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{t.fats}</p>
                </div>
                <p className="text-xl font-black text-slate-900 tracking-tight">{data.fats}g</p>
                <div className="h-1 w-8 bg-red-100 rounded-full">
                  <div className="h-full bg-red-400 rounded-full" style={{ width: `${fPct}%` }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-5 bg-slate-50 rounded-[32px] border border-slate-100 space-y-3">
             <div className="flex items-center justify-between">
               <Scale size={18} className="text-blue-500" />
               <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{t.satiety}</span>
             </div>
             <div>
               <p className={`text-xl font-black ${getSatietyColor(data.satietyLevel)}`}>{data.satietyLevel}</p>
               <div className="flex gap-1 mt-1">
                 {[1,2,3].map(i => (
                   <div key={i} className={`h-1 flex-1 rounded-full ${
                     (data.satietyLevel === 'Alto') ? 'bg-emerald-500' :
                     (data.satietyLevel === 'Médio' && i <= 2) ? 'bg-blue-500' :
                     (data.satietyLevel === 'Baixo' && i === 1) ? 'bg-slate-300' : 'bg-slate-200'
                   }`} />
                 ))}
               </div>
             </div>
          </div>

          <div className="p-5 bg-slate-50 rounded-[32px] border border-slate-100 space-y-3">
             <div className="flex items-center justify-between">
               <Wind size={18} className="text-emerald-500" />
               <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{t.fiber}</span>
             </div>
             <div>
               <p className="text-xl font-black text-slate-900">{data.fiber}g</p>
               <p className="text-[10px] text-emerald-600 font-bold">Excelente digestão</p>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-5 bg-white rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-purple-50 rounded-2xl">
              <Droplets size={20} className="text-purple-500" />
            </div>
            <div className="flex-1">
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{t.sugar}</p>
              <p className="text-lg font-black text-slate-900 leading-none">{data.sugar}g</p>
            </div>
          </div>
          <div className="p-5 bg-white rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-amber-50 rounded-2xl">
              <AlertCircle size={20} className="text-amber-500" />
            </div>
            <div className="flex-1">
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{t.sodium}</p>
              <p className="text-lg font-black text-slate-900 leading-none">{data.sodium}mg</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-black text-slate-900 text-xs uppercase tracking-[0.15em] px-2">{t.ingredients}</h3>
          <div className="flex flex-wrap gap-2">
            {data.ingredients.map((ing, i) => (
              <div key={i} className="px-4 py-2 bg-slate-50 border border-slate-100 rounded-2xl flex items-center gap-2">
                <CheckCircle2 size={14} className="text-emerald-500" />
                <span className="text-sm font-bold text-slate-700 capitalize">{ing}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-6">
          <button 
            onClick={onBack}
            className="w-full py-6 bg-slate-900 text-white rounded-[32px] font-black text-xl shadow-2xl shadow-slate-200 flex items-center justify-center gap-3 active:scale-95 transition-all"
          >
            <Zap size={24} className="text-amber-400 fill-amber-400" />
            {t.newScan}
          </button>
        </div>
      </div>
    </div>
  );
};