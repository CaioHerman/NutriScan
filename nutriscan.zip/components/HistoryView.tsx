
import React from 'react';
import { HistoryEntry, Language } from '../types';
import { translations } from '../translations';
import { ArrowLeft, Flame, Calendar, ChevronRight } from 'lucide-react';

interface HistoryViewProps {
  history: HistoryEntry[];
  onBack: () => void;
  onSelect: (h: HistoryEntry) => void;
  language: Language;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ history, onBack, onSelect, language }) => {
  const t = translations[language];

  return (
    <div className="flex-1 flex flex-col bg-slate-50">
      <div className="p-8 bg-white border-b border-slate-100 flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
          <ArrowLeft size={24} className="text-slate-600" />
        </button>
        <h2 className="text-2xl font-black text-slate-900">{t.history}</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-300">
            <Calendar size={60} className="mb-4 opacity-20" />
            <p className="font-bold">{t.noHistory}</p>
          </div>
        ) : (
          history.map(entry => (
            <button 
              key={entry.id}
              onClick={() => onSelect(entry)}
              className="w-full bg-white p-4 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4 active:scale-[0.98] transition-all"
            >
              <img src={`data:image/jpeg;base64,${entry.image}`} className="w-16 h-16 rounded-2xl object-cover shrink-0" />
              <div className="flex-1 text-left truncate">
                <h3 className="font-black text-slate-900 truncate">{entry.data.foodName}</h3>
                <div className="flex items-center gap-1 text-emerald-600 font-bold text-xs mt-1">
                  <Flame size={12} /> {entry.data.calories} kcal
                </div>
              </div>
              <ChevronRight size={20} className="text-slate-300" />
            </button>
          ))
        )}
      </div>
    </div>
  );
};
