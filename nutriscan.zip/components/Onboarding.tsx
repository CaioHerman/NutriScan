import React from 'react';
import { Camera, Zap, ChevronRight, Target, ShieldCheck, Activity } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface OnboardingProps {
  onStart: () => void;
  language: Language;
  setLanguage: (l: Language) => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ onStart, language, setLanguage }) => {
  const t = translations[language];

  return (
    <div className="flex-1 flex flex-col p-10 bg-white page-fade-in">
      <div className="flex justify-end gap-3 mb-12">
        {(['pt', 'en', 'es'] as Language[]).map(l => (
          <button 
            key={l} 
            onClick={() => setLanguage(l)}
            className={`w-10 h-10 rounded-2xl text-[10px] font-black transition-all border ${language === l ? 'bg-emerald-500 text-white border-emerald-400 shadow-xl shadow-emerald-200' : 'bg-slate-50 text-slate-400 border-slate-100'}`}
          >
            {l.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center text-center space-y-8">
        <div className="relative">
          <div className="w-32 h-32 bg-slate-900 rounded-[44px] shadow-2xl flex items-center justify-center transform -rotate-6">
            <Camera size={64} className="text-emerald-500 rotate-6" />
          </div>
          <div className="absolute -bottom-2 -right-2 w-14 h-14 bg-emerald-500 rounded-3xl flex items-center justify-center border-4 border-white shadow-xl animate-bounce">
            <Zap size={24} className="text-white fill-white" />
          </div>
        </div>
        
        <div className="space-y-3">
          <h1 className="text-5xl font-black text-slate-900 tracking-tighter italic">NutriScan</h1>
          <p className="text-slate-400 text-lg font-medium leading-relaxed max-w-[280px] mx-auto">
            Sua nutrição em <span className="text-slate-900 font-bold italic text-emerald-600">um click</span>.
          </p>
        </div>

        <div className="w-full max-w-xs space-y-4">
           {[
             { icon: Target, label: "Precisão via IA", color: "text-blue-500", bg: "bg-blue-50" },
             { icon: Activity, label: "Histórico Diário", color: "text-purple-500", bg: "bg-purple-50" },
             { icon: ShieldCheck, label: "Privacidade Total", color: "text-emerald-500", bg: "bg-emerald-50" }
           ].map((item, i) => (
             <div key={i} className="flex items-center gap-4 p-4 rounded-3xl bg-slate-50 border border-slate-100">
               <div className={`${item.bg} ${item.color} p-2 rounded-xl`}>
                 <item.icon size={20} />
               </div>
               <span className="text-sm font-bold text-slate-700">{item.label}</span>
             </div>
           ))}
        </div>
      </div>

      <div className="mt-12">
        <button 
          onClick={onStart}
          className="group w-full py-6 bg-slate-900 text-white rounded-[32px] font-black text-xl flex items-center justify-center gap-4 shadow-2xl shadow-slate-300 active:scale-95 transition-all"
        >
          {t.start} 
          <div className="bg-emerald-500 p-1 rounded-full group-hover:translate-x-1 transition-transform">
            <ChevronRight size={20} />
          </div>
        </button>
        <p className="text-center text-[10px] text-slate-300 font-bold uppercase tracking-[0.3em] mt-8">
          Desenvolvido com Google Gemini 3
        </p>
      </div>
    </div>
  );
};