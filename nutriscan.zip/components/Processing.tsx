import React, { useState, useEffect } from 'react';
import { translations } from '../translations';
import { Language } from '../types';
import { Sparkles, Brain, Zap, Loader2 } from 'lucide-react';

export const Processing: React.FC<{ language: Language }> = ({ language }) => {
  const t = translations[language];
  const [tipIndex, setTipIndex] = useState(0);

  const tips = language === 'pt' ? [
    "Escaneando volumetria...",
    "Identificando ingredientes ocultos...",
    "Calculando densidade calórica...",
    "Cruzando dados com Gemini 3 Pro...",
    "Finalizando relatório nutricional..."
  ] : language === 'es' ? [
    "Escaneando volumetría...",
    "Identificando ingredientes ocultos...",
    "Calculando densidad calórica...",
    "Analizando con Gemini 3 Pro...",
    "Finalizando informe nutricional..."
  ] : [
    "Scanning volume...",
    "Identifying hidden ingredients...",
    "Calculating caloric density...",
    "Processing with Gemini 3 Pro...",
    "Finalizing nutritional report..."
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTipIndex(prev => (prev + 1) % tips.length);
    }, 2000);
    return () => clearInterval(timer);
  }, [tips.length]);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-12 bg-white text-center page-fade-in">
      <div className="relative mb-12">
        {/* Outer Ring */}
        <div className="w-36 h-36 border-[12px] border-emerald-50 rounded-full" />
        {/* Animated Ring */}
        <div className="absolute inset-0 border-[12px] border-emerald-500 border-t-transparent rounded-full animate-spin" />
        {/* Center Icon */}
        <div className="absolute inset-0 flex items-center justify-center">
           <div className="bg-emerald-500 p-5 rounded-3xl shadow-xl shadow-emerald-200 animate-pulse">
             <Brain className="text-white" size={44} />
           </div>
        </div>
        {/* Floating Badges */}
        <div className="absolute -top-4 -right-4 bg-amber-400 p-3 rounded-2xl shadow-xl animate-bounce">
          <Zap size={20} className="text-white fill-white" />
        </div>
        <div className="absolute -bottom-2 -left-4 bg-blue-500 p-2 rounded-xl shadow-lg animate-pulse delay-75">
          <Sparkles size={16} className="text-white" />
        </div>
      </div>

      <div className="space-y-6">
        <h2 className="text-3xl font-black text-slate-900 tracking-tight leading-none">
          {t.processing}
        </h2>
        <div className="h-14 flex flex-col items-center justify-center px-4">
          <p className="text-emerald-600 font-black text-[11px] uppercase tracking-[0.25em] animate-pulse">
            {tips[tipIndex]}
          </p>
          <div className="flex gap-1 mt-3">
             {[0, 1, 2].map(i => (
               <div key={i} className={`w-1.5 h-1.5 rounded-full bg-emerald-500/30 animate-bounce`} style={{ animationDelay: `${i * 0.2}s` }} />
             ))}
          </div>
        </div>
      </div>
      
      <div className="mt-16 w-56 h-1.5 bg-slate-100 rounded-full overflow-hidden relative">
        <div className="h-full bg-emerald-500 animate-loading-bar" />
      </div>

      <p className="mt-8 text-[10px] text-slate-300 font-bold uppercase tracking-[0.3em]">
        Exclusivo NutriScan AI
      </p>

      <style>{`
        @keyframes loading-bar {
          0% { width: 0%; left: -100%; }
          50% { width: 100%; left: 0%; }
          100% { width: 0%; left: 100%; }
        }
        .animate-loading-bar {
          position: absolute;
          animation: loading-bar 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};